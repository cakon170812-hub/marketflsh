// Este paquete de Android usa los archivos incluidos en www.
// No activar service worker independiente: evita cachés web obsoletas.
